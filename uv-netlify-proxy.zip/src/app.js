document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("goForm");
  const input = document.getElementById("urlInput");
  const iframe = document.getElementById("proxyFrame");

  function openProxy(url) {
    try {
      const u = new URL(url);
      const proxied = `/proxy?url=${encodeURIComponent(u.toString())}`;
      iframe.src = proxied;
    } catch (e) {
      alert("Enter a valid URL starting with https:// or http://");
    }
  }

  form.addEventListener("submit", (ev) => {
    ev.preventDefault();
    openProxy(input.value.trim());
  });

  input.addEventListener("keyup", (e) => {
    if (e.key === "Enter") openProxy(input.value.trim());
  });
});
