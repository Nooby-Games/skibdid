# UV Netlify Proxy (demo)

This repo demonstrates a small "Ultraviolet-style" proxy using:
- a static frontend in `/src`
- Netlify Functions backend `netlify/functions/proxy.js`

See the instructions in the ChatGPT response for full details.
